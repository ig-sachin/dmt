package com.dmt.backend.engine.form.service;

import com.dmt.backend.engine.form.dto.FormFieldResponse;
import com.dmt.backend.engine.form.dto.FormResponse;
import com.dmt.backend.metadata.column.entity.DmtColumn;
import com.dmt.backend.metadata.column.repository.DmtColumnRepository;
import com.dmt.backend.metadata.screen.entity.DmtScreen;
import com.dmt.backend.metadata.screen.repository.DmtScreenRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class FormEngineService {

    private final DmtScreenRepository screenRepository;
    private final DmtColumnRepository columnRepository;

    public FormResponse getForm(
            String screenCode) {

        DmtScreen screen =
                screenRepository
                        .findByScreenCode(screenCode)
                        .orElseThrow(() ->
                                new RuntimeException(
                                        "Screen not found"));

        List<FormFieldResponse> fields =
                columnRepository
                        .findByScreenScreenCodeOrderByDisplayOrderAsc(
                                screenCode)
                        .stream()
                        .map(this::map)
                        .toList();

        return new FormResponse(
                screen.getScreenCode(),
                screen.getScreenName(),
                fields
        );
    }

    private FormFieldResponse map(
            DmtColumn column) {

        return new FormFieldResponse(

                column.getColumnName(),

                column.getDisplayName(),

                column.getDataType(),

                column.getFieldType().name(),

                column.getVisible(),

                column.getEditable(),

                column.getMandatory(),

                column.getDefaultValue(),

                column.getDisplayOrder(),

                column.getWidth(),

                column.getAlignment(),

                column.getFormatMask(),

                column.getPlaceholder(),

                column.getMaxLength(),

                column.getDropdownCode()
        );
    }
}