package com.dmt.backend.engine.crud.service;

import com.dmt.backend.engine.procedure.dto.ProcedureExecutionRequest;
import com.dmt.backend.engine.procedure.dto.ProcedureExecutionResponse;
import com.dmt.backend.engine.procedure.service.ProcedureEngineService;
import com.dmt.backend.metadata.procedure.entity.OperationType;
import com.dmt.backend.security.ScreenAuthorizationService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service
@RequiredArgsConstructor
@Slf4j
public class GenericCrudService {

    private final ProcedureEngineService procedureEngineService;
    private final ScreenAuthorizationService authorizationService;

    public ProcedureExecutionResponse insert(
            String screenCode,
            Map<String, Object> values) {

        authorizationService.authorize(screenCode);
        log.info(
                "Generic CRUD authorization successful operationType={} screenCode={}",
                OperationType.INSERT,
                screenCode
        );
        log.info(
                "Generic CRUD requested operationType={} screenCode={} valueKeys={}",
                OperationType.INSERT,
                screenCode,
                values == null ? null : values.keySet()
        );

        ProcedureExecutionResponse response = procedureEngineService.execute(
                new ProcedureExecutionRequest(
                        screenCode,
                        OperationType.INSERT,
                        values
                )
        );

        log.info(
                "Generic CRUD completed operationType={} screenCode={} success={} message={}",
                OperationType.INSERT,
                screenCode,
                response.success(),
                response.message()
        );

        return response;
    }

    public ProcedureExecutionResponse update(
            String screenCode,
            Map<String, Object> values) {

        authorizationService.authorize(screenCode);
        log.info(
                "Generic CRUD authorization successful operationType={} screenCode={}",
                OperationType.UPDATE,
                screenCode
        );
        log.info(
                "Generic CRUD requested operationType={} screenCode={} valueKeys={}",
                OperationType.UPDATE,
                screenCode,
                values == null ? null : values.keySet()
        );

        ProcedureExecutionResponse response = procedureEngineService.execute(
                new ProcedureExecutionRequest(
                        screenCode,
                        OperationType.UPDATE,
                        values
                )
        );

        log.info(
                "Generic CRUD completed operationType={} screenCode={} success={} message={}",
                OperationType.UPDATE,
                screenCode,
                response.success(),
                response.message()
        );

        return response;
    }

    public ProcedureExecutionResponse delete(
            String screenCode,
            Map<String, Object> values) {

        authorizationService.authorize(screenCode);
        log.info(
                "Generic CRUD authorization successful operationType={} screenCode={}",
                OperationType.DELETE,
                screenCode
        );
        log.info(
                "Generic CRUD requested operationType={} screenCode={} valueKeys={}",
                OperationType.DELETE,
                screenCode,
                values == null ? null : values.keySet()
        );

        ProcedureExecutionResponse response = procedureEngineService.execute(
                new ProcedureExecutionRequest(
                        screenCode,
                        OperationType.DELETE,
                        values
                )
        );

        log.info(
                "Generic CRUD completed operationType={} screenCode={} success={} message={}",
                OperationType.DELETE,
                screenCode,
                response.success(),
                response.message()
        );

        return response;
    }
}
