package com.dmt.backend.metadata.validation.entity;

public class DmtValidation {
}
