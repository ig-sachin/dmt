package com.dmt.backend;

import org.junit.platform.suite.api.SelectClasses;
import org.junit.platform.suite.api.Suite;

@Suite
@SelectClasses({
        CrudIntegrationTest.class,
        MetadataIntegrationTest.class,
        ProcedureEngineIntegrationTest.class,
        QueryEngineIntegrationTest.class,
        SecurityIntegrationTest.class,
        ScreenAuthorizationServiceTest.class,
        ScreenRoleControllerIntegrationTest.class
})
public class DmtBackendApplicationTests {
}